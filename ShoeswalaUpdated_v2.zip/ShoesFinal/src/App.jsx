import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Navbar         from './Components/Navbar';
import Footer         from './Components/Footer';
import Home           from './Pages/Home';
import Products       from './Pages/Products';
import Collections    from './Pages/Collections';
import ProductDetails from './Pages/ProductDetails';
import Cart           from './Pages/Cart';
import AdminPanel     from './Pages/AdminPanel';

// ─── Full-Width Discount Ticker ───────────────────────────────────────────────
const DiscountTicker = () => {
  const msg = "🎉 RS. 5000 YA US SE ZYADA KI SHOPPING PAR 20% DISCOUNT MILEGA! • SHOP & SAVE • ";
  const repeated = Array(12).fill(msg).join('');

  return (
    <div
      className="fixed left-0 right-0 z-40 overflow-hidden select-none"
      style={{
        top: '72px', // bilkul navbar ke neeche
        background: '#0a0a0a',
        borderBottom: '1px solid #1f1f1f',
        borderTop: '1px solid #1f1f1f',
        height: '36px',
        display: 'flex',
        alignItems: 'center',
      }}
    >
      <div
        style={{
          display: 'flex',
          whiteSpace: 'nowrap',
          animation: 'discountTicker 28s linear infinite',
          willChange: 'transform',
        }}
      >
        <span className="font-black uppercase tracking-widest" style={{ fontSize: '10px', color: '#ffffff', paddingRight: '0' }}>
          {repeated}
        </span>
        <span className="font-black uppercase tracking-widest" style={{ fontSize: '10px', color: '#ffffff', paddingRight: '0' }}>
          {repeated}
        </span>
      </div>

      <style>{`
        @keyframes discountTicker {
          0%   { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
};

function App() {
  const [cartItems, setCartItems]     = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  const addToCart      = (item) => setCartItems((prev) => [...prev, item]);
  const removeFromCart = (idx)  => setCartItems((prev) => prev.filter((_, i) => i !== idx));
  const clearCart      = ()     => setCartItems([]);

  return (
    <Router>
      {/* Fixed Navbar */}
      <Navbar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        cartCount={cartItems.length}
      />

      {/* Full-width discount ticker — navbar ke bilkul neeche, poore page ki width mein */}
      <DiscountTicker />

      {/* pt-[108px] = 72px navbar + 36px ticker */}
      <main className="pt-[108px]" style={{ background: '#0a0a0a', minHeight: '100vh' }}>
        <Routes>
          <Route path="/"            element={<Home addToCart={addToCart} />} />
          <Route path="/products"    element={<Products searchQuery={searchQuery} addToCart={addToCart} />} />
          <Route path="/collections" element={<Collections />} />
          <Route path="/product/:id" element={<ProductDetails addToCart={addToCart} />} />
          <Route path="/cart"        element={<Cart cartItems={cartItems} removeFromCart={removeFromCart} clearCart={clearCart} />} />
          <Route path="/admin"       element={<AdminPanel />} />
        </Routes>
      </main>

      <Footer />
    </Router>
  );
}

export default App;
