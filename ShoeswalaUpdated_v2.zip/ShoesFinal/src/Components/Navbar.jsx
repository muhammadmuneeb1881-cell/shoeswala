import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Search, X, ShoppingCart, Menu } from 'lucide-react';

const Navbar = ({ searchQuery, setSearchQuery, cartCount }) => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    if (window.location.pathname !== '/products') {
      navigate('/products');
    }
  };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 px-6 md:px-12 py-4 flex items-center justify-between"
      style={{ background: '#0a0a0a', borderBottom: '1px solid #1f1f1f', boxShadow: '0 4px 30px rgba(0,0,0,0.5)' }}
    >
      {/* BRAND LOGO */}
      <Link to="/" className="flex items-center gap-2 flex-shrink-0">
        <div className="text-white font-black text-xl tracking-tighter uppercase italic flex items-center justify-center w-10 h-10 rounded-xl" style={{ background: '#EA580C' }}>
          S
        </div>
        <span className="font-black text-xl tracking-tighter uppercase" style={{ color: '#ffffff' }}>
          SHOES<span style={{ color: '#EA580C' }}>WALA</span>
        </span>
      </Link>

      {/* NAV LINKS - Desktop */}
      <div className="hidden md:flex items-center gap-8 text-[11px] font-black uppercase tracking-widest" style={{ color: '#9ca3af' }}>
        <Link to="/"            className="hover:text-orange-500 transition-colors" style={{ color: 'inherit' }}>Home</Link>
        <Link to="/products"    className="hover:text-orange-500 transition-colors" style={{ color: 'inherit' }}>Products</Link>
        <Link to="/collections" className="hover:text-orange-500 transition-colors" style={{ color: 'inherit' }}>Collections</Link>
      </div>

      {/* RIGHT SIDE */}
      <div className="flex items-center gap-3">
        {/* SEARCH */}
        <div className="relative group hidden sm:block w-48 md:w-56">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-orange-500 transition-colors" size={14} />
          <input
            type="text"
            placeholder="SEARCH..."
            value={searchQuery || ''}
            onChange={handleSearchChange}
            className="w-full rounded-full py-2 pl-10 pr-9 outline-none text-[10px] font-bold uppercase tracking-widest transition-all"
            style={{ background: '#1a1a1a', border: '1px solid #2f2f2f', color: '#ffffff' }}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors">
              <X size={12} />
            </button>
          )}
        </div>

        {/* CART */}
        <Link to="/cart"
          className="relative flex items-center justify-center w-10 h-10 rounded-xl transition-all"
          style={{ background: '#1a1a1a', border: '1px solid #2f2f2f' }}>
          <ShoppingCart size={18} style={{ color: '#ffffff' }} />
          {cartCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 text-white text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center" style={{ background: '#EA580C' }}>
              {cartCount}
            </span>
          )}
        </Link>

        {/* MOBILE MENU TOGGLE */}
        <button
          className="md:hidden flex items-center justify-center w-10 h-10 rounded-xl"
          style={{ background: '#1a1a1a', border: '1px solid #2f2f2f' }}
          onClick={() => setMenuOpen(!menuOpen)}>
          <Menu size={18} style={{ color: '#ffffff' }} />
        </button>
      </div>

      {/* MOBILE MENU */}
      {menuOpen && (
        <div className="absolute top-full left-0 right-0 flex flex-col gap-1 px-6 py-4 md:hidden"
          style={{ background: '#111111', borderBottom: '1px solid #2f2f2f' }}>
          <Link to="/"            onClick={() => setMenuOpen(false)} className="py-2 text-sm font-bold uppercase tracking-widest" style={{ color: '#ffffff' }}>Home</Link>
          <Link to="/products"    onClick={() => setMenuOpen(false)} className="py-2 text-sm font-bold uppercase tracking-widest" style={{ color: '#ffffff' }}>Products</Link>
          <Link to="/collections" onClick={() => setMenuOpen(false)} className="py-2 text-sm font-bold uppercase tracking-widest" style={{ color: '#ffffff' }}>Collections</Link>
          <div className="relative mt-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={14} />
            <input
              type="text"
              placeholder="SEARCH..."
              value={searchQuery || ''}
              onChange={handleSearchChange}
              className="w-full rounded-full py-2 pl-9 pr-4 outline-none text-[10px] font-bold uppercase tracking-widest"
              style={{ background: '#1a1a1a', border: '1px solid #2f2f2f', color: '#ffffff' }}
            />
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
