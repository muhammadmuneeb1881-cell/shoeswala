import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FaFacebookF, FaInstagram } from "react-icons/fa6";
import { FaEnvelope, FaGlobe, FaArrowUpRightFromSquare } from "react-icons/fa6";

// ─── Footer ───────────────────────────────────────────────────────────────────
const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    "The Collection": [
      { name: 'New Arrivals',    path: '/products' },
      { name: 'Best Sellers',    path: '/products' },
      { name: 'Limited Edition', path: '/products' },
      { name: 'Sale Events',     path: '/products' },
    ],
    "Get Help": [
      { name: 'Order Tracking',  path: '#' },
      { name: 'Fast Delivery',   path: '#' },
      { name: 'Exchange Policy', path: '#' },
      { name: 'Contact Support', path: '#' },
    ],
    "Our World": [
      { name: 'The Story',       path: '#' },
      { name: 'Retail Stores',   path: '#' },
      { name: 'Sustainability',  path: '#' },
    ]
  };

  // Only FB and Instagram
  const socialIcons = [
    { Icon: FaFacebookF, href: "https://www.facebook.com/mun.eeb.318397",  label: "Facebook" },
    { Icon: FaInstagram, href: "https://www.instagram.com/muneeb_nomani/", label: "Instagram" },
  ];

  return (
    <footer className="bg-white text-zinc-950 pt-24 pb-12 overflow-hidden border-t-4 border-zinc-950">
      <style>{`
        @keyframes ticker {
          0%   { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>

      <div className="max-w-[1440px] mx-auto px-6 md:px-12">

        {/* Newsletter & Brand Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 pb-24">
          <div className="lg:col-span-5 space-y-6">

            {/* LOGO */}
            <Link to="/" className="text-6xl font-[1000] italic tracking-[calc(-0.05em)] uppercase leading-none block">
              SHOES<span className="text-orange-600">WALA</span>
            </Link>

            {/* Sliding Discount Banner — footer mein bhi rakha (small version) */}
            <div
              className="overflow-hidden rounded-xl py-3 select-none -mx-1"
              style={{ background: '#0a0a0a' }}
            >
              <div
                style={{
                  display: 'flex',
                  whiteSpace: 'nowrap',
                  animation: 'ticker 25s linear infinite',
                }}
              >
                {[0, 1].map(n => (
                  <span
                    key={n}
                    className="font-black uppercase text-[10px] tracking-widest"
                    style={{ color: '#ffffff', paddingRight: '2rem' }}
                  >
                    {Array(8).fill("🎉 Rs. 5000 ya us se zyada ki shopping par 20% DISCOUNT milega! • Shop & Save • ").join('')}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-[1000] italic uppercase leading-[0.95] tracking-tighter max-w-sm">
                Unlock <span className="text-zinc-300">Insider</span> Access &{' '}
                <span className="text-orange-600">15% Off</span>
              </h2>

              <div className="flex flex-col sm:flex-row gap-3 max-w-md">
                <div className="relative flex-grow group">
                  <FaEnvelope className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-orange-600 transition-colors" />
                  <input
                    type="email"
                    placeholder="ENTER YOUR EMAIL"
                    className="w-full bg-zinc-50 border-2 border-zinc-100 rounded-none py-5 pl-14 pr-4 outline-none focus:border-orange-600 text-xs font-black uppercase tracking-widest placeholder:text-zinc-300 transition-all"
                  />
                </div>
                <button className="bg-zinc-950 text-white px-8 py-5 rounded-none font-[1000] uppercase italic text-xs tracking-[0.2em] hover:bg-orange-600 transition-all active:scale-95 shadow-2xl">
                  Join Now
                </button>
              </div>
            </div>
          </div>

          {/* Links Grid */}
          <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-12">
            {Object.entries(footerLinks).map(([title, links]) => (
              <div key={title} className="space-y-8">
                <h4 className="text-zinc-950 font-[1000] uppercase text-[11px] tracking-[0.3em] italic border-b-2 border-zinc-100 pb-4 inline-block w-full">
                  {title}
                </h4>
                <ul className="space-y-5">
                  {links.map((link) => (
                    <li key={link.name}>
                      <Link
                        to={link.path}
                        className="text-zinc-500 hover:text-orange-600 transition-all text-sm font-black uppercase tracking-tight flex items-center group italic"
                      >
                        <span className="group-hover:translate-x-1 transition-transform">{link.name}</span>
                        <FaArrowUpRightFromSquare size={10} className="ml-2 opacity-0 group-hover:opacity-100 text-orange-600 transition-all" />
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Social Icons Only — no phone number */}
        <div className="py-12 border-y-2 border-zinc-100 flex items-center justify-between">
          <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Follow Us</p>

          <div className="flex items-center gap-4">
            {socialIcons.map(({ Icon, href, label }, idx) => (
              <motion.a
                key={idx}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                whileHover={{ scale: 1.1, rotate: 5 }}
                className="w-14 h-14 bg-zinc-50 border-2 border-zinc-100 rounded-2xl flex items-center justify-center hover:bg-orange-600 hover:border-orange-600 hover:text-white transition-all text-xl shadow-sm text-zinc-950"
              >
                <Icon />
              </motion.a>
            ))}
          </div>
        </div>

        {/* Copyright & Legal */}
        <div className="pt-12 flex flex-col lg:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-zinc-400">
            <FaGlobe className="text-zinc-950" />
            <span>&copy; {currentYear} SHOESWALA INTERACTIVE — ALL RIGHTS RESERVED</span>
          </div>

          <div className="flex gap-10 text-[10px] font-black text-zinc-950 uppercase tracking-widest italic">
            <Link to="#" className="hover:text-orange-600 border-b-2 border-transparent hover:border-orange-600 transition-all">Privacy</Link>
            <Link to="#" className="hover:text-orange-600 border-b-2 border-transparent hover:border-orange-600 transition-all">Terms</Link>
            <Link to="#" className="hover:text-orange-600 border-b-2 border-transparent hover:border-orange-600 transition-all">Cookies</Link>
          </div>
        </div>

      </div>
    </footer>
  );
};

export default Footer;
