import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MoveRight, ShoppingCart, ShoppingBag, Zap, Award, Target } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
};

const WHATSAPP_NUMBER = '923122347756';

const DEFAULT_PRODUCTS = [
  { id: 1, brand: "Nike", name: "Air Max Pulse", price: 34995, category: "Lifestyle", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=800&auto=format&fit=crop", status: "New Drop", stock: 12 },
  { id: 2, brand: "Yeezy", name: "Boost 350 V2 'Onyx'", price: 52495, category: "Lifestyle", image: "https://images.unsplash.com/photo-1582588564157-60370c2170fe?q=80&w=800&auto=format&fit=crop", status: "Limited Release", stock: 6 },
  { id: 3, brand: "New Balance", name: "9060 'Sea Salt'", price: 31995, category: "Lifestyle", image: "https://images.unsplash.com/photo-1639144345371-9df608402534?q=80&w=800&auto=format&fit=crop", status: "Trending", stock: 15 },
];

const Home = ({ addToCart }) => {
  const navigate = useNavigate();
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [addedId, setAddedId] = useState(null);

  useEffect(() => {
    const stored = localStorage.getItem('sw_products');
    const list = stored ? JSON.parse(stored) : DEFAULT_PRODUCTS;
    setFeaturedProducts(list.slice(0, 3));
  }, []);

  const handleAddToCart = (e, product) => {
    e.stopPropagation();
    addToCart(product);
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  const makeWhatsAppLink = (shoe) => {
    const msg = `Assalam o Alaikum! 🛒\nMujhe yeh shoe order karni hai:\n\n👟 ${shoe.brand} - ${shoe.name}\n💰 Price: Rs. ${shoe.price.toLocaleString()}\n\nKya available hai?`;
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
  };

  return (
    <div className="overflow-hidden" style={{ background: '#0a0a0a' }}>

      {/* ── HERO ── */}
      <section className="relative min-h-[95vh] flex items-center justify-center px-6 overflow-hidden" style={{ background: '#0a0a0a' }}>
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
          <h1 className="text-[25vw] font-black italic uppercase tracking-tighter leading-none" style={{ color: '#111111' }}>KICK</h1>
        </div>
        <div className="absolute left-0 top-0 bottom-0 w-1" style={{ background: '#EA580C' }}></div>

        <div className="max-w-[1440px] mx-auto grid lg:grid-cols-2 gap-12 items-center z-10 w-full">
          <motion.div initial="hidden" animate="visible" variants={fadeInUp} className="space-y-8 text-center lg:text-left">
            <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full" style={{ background: '#1a1a1a', border: '1px solid #2f2f2f' }}>
              <span className="flex h-2 w-2 rounded-full animate-pulse" style={{ background: '#EA580C' }}></span>
              <span className="text-[9px] font-black uppercase tracking-[0.4em]" style={{ color: '#9ca3af' }}>Exclusive Drop: Winter 2026</span>
            </div>

            <h2 className="text-7xl md:text-[10rem] font-black leading-[0.8] tracking-tighter italic uppercase" style={{ color: '#ffffff' }}>
              FAST <br /> <span style={{ color: '#EA580C' }}>LIFE.</span>
            </h2>

            <p className="max-w-sm mx-auto lg:mx-0 font-bold leading-relaxed uppercase text-[11px] tracking-widest" style={{ color: '#6b7280' }}>
              High-performance kicks for the ones who set the pace. Pure comfort, zero limits.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-2">
              <Link to="/products">
                <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  className="text-white px-10 py-5 rounded-2xl font-black uppercase italic tracking-widest flex items-center group gap-4 shadow-2xl"
                  style={{ background: '#EA580C' }}>
                  Shop Now <MoveRight size={20} className="group-hover:translate-x-2 transition-transform" />
                </motion.button>
              </Link>
              <Link to="/cart">
                <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  className="text-white px-10 py-5 rounded-2xl font-black uppercase italic tracking-widest flex items-center gap-4"
                  style={{ background: '#1a1a1a', border: '1px solid #2f2f2f' }}>
                  View Cart <ShoppingCart size={20} />
                </motion.button>
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotate: 15 }}
            animate={{ opacity: 1, scale: 1, rotate: -12 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="relative"
          >
            <img
              src="https://images.unsplash.com/photo-1542291026-7eec264c27ff"
              alt="Hero Shoe"
              className="w-full drop-shadow-[0_60px_100px_rgba(234,88,12,0.3)] hover:rotate-[-5deg] transition-transform duration-700"
            />
          </motion.div>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section className="py-28 relative" style={{ background: '#111111' }}>
        <div className="max-w-[1440px] mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
            {[
              { icon: <Zap size={36} />,    title: "V-Force Sole",   desc: "Propulsive energy return in every step." },
              { icon: <Award size={36} />,  title: "Elite Material", desc: "Premium waterproof mesh and carbon fiber." },
              { icon: <Target size={36} />, title: "True FitTech",   desc: "Adaptive lacing that locks your foot in." },
            ].map((f, i) => (
              <div key={i} className="space-y-5 p-8 rounded-3xl" style={{ background: '#1a1a1a', border: '1px solid #2f2f2f' }}>
                <div style={{ color: '#EA580C' }}>{f.icon}</div>
                <h3 className="text-3xl font-black italic uppercase tracking-tighter leading-none" style={{ color: '#ffffff' }}>{f.title}</h3>
                <p className="text-xs font-bold leading-relaxed uppercase tracking-wider" style={{ color: '#6b7280' }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED PRODUCTS ── */}
      <section className="py-28 px-6" style={{ background: '#0a0a0a' }}>
        <div className="max-w-[1440px] mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6 pb-10" style={{ borderBottom: '3px solid #EA580C' }}>
            <h2 className="text-7xl font-black tracking-tighter italic uppercase leading-none" style={{ color: '#ffffff' }}>
              THE <span style={{ color: '#EA580C' }}>HEAT.</span>
            </h2>
            <Link to="/products"
              className="text-[10px] font-black uppercase tracking-[0.4em] px-8 py-4 rounded-xl transition-all"
              style={{ background: '#1a1a1a', color: '#ffffff', border: '1px solid #2f2f2f' }}>
              View All Products
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {featuredProducts.map((shoe) => (
              <motion.div key={shoe.id} whileHover={{ y: -8 }}
                className="group space-y-5 cursor-pointer"
                onClick={() => navigate(`/product/${shoe.id}`)}>
                <div className="aspect-square rounded-[2.5rem] p-10 flex items-center justify-center relative overflow-hidden transition-all"
                  style={{ background: '#1a1a1a', border: '1px solid #2f2f2f' }}>
                  <img src={shoe.image}
                    className="w-full object-contain group-hover:scale-110 group-hover:-rotate-6 transition-transform duration-700 mix-blend-luminosity"
                    alt={shoe.name} />
                  <button onClick={(e) => handleAddToCart(e, shoe)}
                    className="absolute bottom-6 right-6 text-white p-4 rounded-2xl scale-0 group-hover:scale-100 transition-transform duration-400 shadow-xl font-black text-xs uppercase tracking-wider flex items-center gap-2"
                    style={{ background: addedId === shoe.id ? '#16a34a' : '#EA580C' }}>
                    {addedId === shoe.id ? '✓ Added' : <ShoppingBag size={18} />}
                  </button>
                </div>
                <div className="flex justify-between items-start px-2">
                  <div>
                    {shoe.status && <span className="text-[9px] font-black uppercase tracking-widest" style={{ color: '#EA580C' }}>{shoe.status}</span>}
                    <h3 className="text-xl font-black uppercase italic tracking-tighter mt-1" style={{ color: '#ffffff' }}>{shoe.brand}</h3>
                    <p className="text-sm font-bold" style={{ color: '#6b7280' }}>{shoe.name}</p>
                  </div>
                  <span className="text-xl font-black italic" style={{ color: '#ffffff' }}>Rs. {shoe.price.toLocaleString()}</span>
                </div>
                <a href={makeWhatsAppLink(shoe)} target="_blank" rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="block mx-2 py-3 rounded-xl text-center text-xs font-black uppercase tracking-wider transition-all"
                  style={{ background: '#1a1a1a', color: '#25D366', border: '1px solid #2f2f2f' }}>
                  📱 Order on WhatsApp
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-32 text-center relative overflow-hidden" style={{ background: '#111111' }}>
        <div className="absolute inset-0 opacity-5 pointer-events-none overflow-hidden">
          <h2 className="text-[150px] font-black italic uppercase tracking-tighter leading-none" style={{ color: '#EA580C' }}>SHOESWALA</h2>
        </div>
        <div className="relative z-10 space-y-8">
          <h2 className="text-6xl md:text-[8rem] font-black italic tracking-tight uppercase leading-none" style={{ color: '#ffffff' }}>
            OWN YOUR <br /> <span style={{ color: '#EA580C' }}>STRIDE.</span>
          </h2>
          <div className="h-1 w-24 mx-auto" style={{ background: '#EA580C' }}></div>
          <a href="https://wa.me/923122347756?text=Assalam%20o%20Alaikum!%20Mujhe%20order%20karna%20hai."
            target="_blank" rel="noopener noreferrer"
            className="inline-block px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-sm transition-all hover:scale-105"
            style={{ background: '#25D366', color: '#ffffff' }}>
            📱 WhatsApp Par Order Karein
          </a>
          <p className="text-[10px] font-black uppercase tracking-[0.5em]" style={{ color: '#4b5563' }}>Shoeswala Premium ©2026 — Karachi, Pakistan</p>
        </div>
      </section>
    </div>
  );
};

export default Home;
