import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

const COLLECTIONS = [
  {
    id: 1,
    title: "Lifestyle",
    subtitle: "Street Culture",
    desc: "Sneakers made for the streets. Bold designs, premium materials, everyday comfort.",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=800&auto=format&fit=crop",
    count: 4,
    accent: "#EA580C",
  },
  {
    id: 2,
    title: "Basketball",
    subtitle: "Court Dominance",
    desc: "Performance court shoes engineered for explosive plays and ankle support.",
    image: "https://images.unsplash.com/photo-1612817159949-195b6eb9e31a?q=80&w=800&auto=format&fit=crop",
    count: 3,
    accent: "#3B82F6",
  },
  {
    id: 3,
    title: "Running",
    subtitle: "Go the Distance",
    desc: "Lightweight, responsive running shoes built to take you farther, faster.",
    image: "https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?q=80&w=800&auto=format&fit=crop",
    count: 2,
    accent: "#16A34A",
  },
  {
    id: 4,
    title: "Training",
    subtitle: "Gym Ready",
    desc: "Stable and durable trainers for every workout — from HIIT to heavy lifts.",
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=800&auto=format&fit=crop",
    count: 2,
    accent: "#9333EA",
  },
];

const Collections = () => {
  return (
    <div className="min-h-screen pt-24 pb-20" style={{ background: '#0a0a0a' }}>
      <div className="max-w-[1440px] mx-auto px-6 md:px-12">

        {/* HEADER */}
        <div className="mb-20">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <p className="text-[9px] font-black uppercase tracking-[0.5em] text-orange-600 mb-4">Curated For You</p>
            <h1 className="text-7xl md:text-[9rem] font-[1000] italic uppercase tracking-tighter leading-[0.8] text-white">
              The <br /><span className="text-orange-600">Collections.</span>
            </h1>
            <p className="text-zinc-500 font-bold uppercase text-[10px] tracking-[0.3em] mt-6 max-w-sm">
              Four categories. One obsession. Find your perfect pair.
            </p>
          </motion.div>
        </div>

        {/* COLLECTIONS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {COLLECTIONS.map((col, idx) => (
            <motion.div
              key={col.id}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <Link to={`/products`} className="group block relative overflow-hidden rounded-[2.5rem]"
                style={{ background: '#111111', border: '1px solid #1f1f1f' }}>
                <div className="aspect-[4/3] relative overflow-hidden">
                  <img src={col.image} alt={col.title}
                    className="w-full h-full object-cover mix-blend-luminosity opacity-60 group-hover:opacity-80 group-hover:scale-105 transition-all duration-700" />
                  <div className="absolute inset-0" style={{ background: `linear-gradient(to top, #0a0a0a 30%, transparent 70%)` }}></div>

                  {/* Accent stripe */}
                  <div className="absolute top-0 left-0 w-1 h-full" style={{ background: col.accent }}></div>

                  {/* Category badge */}
                  <div className="absolute top-8 right-8">
                    <span className="text-[8px] font-black uppercase tracking-widest px-4 py-2 rounded-full text-white"
                      style={{ background: col.accent }}>
                      {col.count} Products
                    </span>
                  </div>
                </div>

                <div className="p-10 -mt-4 relative">
                  <p className="text-[9px] font-black uppercase tracking-[0.4em] mb-2" style={{ color: col.accent }}>{col.subtitle}</p>
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-5xl font-[1000] italic uppercase tracking-tighter text-white leading-none">{col.title}</h2>
                      <p className="text-zinc-500 text-xs font-bold mt-3 max-w-xs leading-relaxed">{col.desc}</p>
                    </div>
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all flex-shrink-0 ml-4 mt-1"
                      style={{ background: col.accent }}>
                      <ArrowUpRight size={20} className="text-white" />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* BOTTOM CTA */}
        <div className="mt-20 text-center">
          <p className="text-zinc-600 text-[10px] font-black uppercase tracking-widest mb-6">Can't decide? Browse everything</p>
          <Link to="/products"
            className="inline-block px-12 py-5 rounded-2xl font-black uppercase italic tracking-widest text-sm text-white transition-all hover:scale-105"
            style={{ background: '#EA580C' }}>
            View All Products
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Collections;
