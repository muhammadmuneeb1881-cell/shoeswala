import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingBag, ArrowLeft } from 'lucide-react';

const WHATSAPP_NUMBER = '923122347756';

const MOCK_PRODUCTS = [
  { id: 1,  brand: "Nike",        name: "Air Max Pulse",          price: 34995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",        desc: "Premium cushioning sneaker built for comfort and style.", stock: 12, status: "New Drop" },
  { id: 2,  brand: "Yeezy",       name: "Boost 350 V2 'Onyx'",    price: 52495, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1582588564157-60370c2170fe",        desc: "Iconic Yeezy design with ultra comfort Boost sole.", stock: 6, status: "Limited Release" },
  { id: 3,  brand: "New Balance", name: "9060 'Sea Salt'",         price: 31995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1639144345371-9df608402534",        desc: "Chunky silhouette with premium suede and mesh upper.", stock: 15, status: "Trending" },
  { id: 4,  brand: "Nike",        name: "Dunk Low 'Panda'",        price: 24995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519",        desc: "Classic black and white colorway. A timeless icon.", stock: 25, status: "Restocked" },
  { id: 5,  brand: "Nike",        name: "Zoom Freak 5",            price: 28895, category: "Basketball", image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa",        desc: "Giannis signature shoe built for court dominance.", stock: 5, status: "Performance Elite" },
  { id: 6,  brand: "Jordan",      name: "AJ4 'Thunder'",           price: 68995, category: "Basketball", image: "https://images.unsplash.com/photo-1612817159949-195b6eb9e31a",        desc: "Iconic Air Jordan 4 in the legendary Thunder colorway.", stock: 3, status: "Grail" },
  { id: 7,  brand: "Jordan",      name: "Air Jordan 1 High",       price: 46995, category: "Basketball", image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a",        desc: "The original. Where it all started.", stock: 0, status: "Sold Out" },
  { id: 8,  brand: "Adidas",      name: "Ultraboost Light",        price: 38999, category: "Running",    image: "https://images.unsplash.com/photo-1587563871167-1ee9c731aefb",        desc: "Lightest Ultraboost ever made. Maximum energy return.", stock: 9, status: "Best Seller" },
  { id: 9,  brand: "Hoka",        name: "Bondi 8 Black",           price: 27495, category: "Running",    image: "https://images.unsplash.com/photo-1620138546344-7b2c38516dee",        desc: "Maximum cushion for your maximum miles.", stock: 14, status: "Comfort King" },
  { id: 10, brand: "Nike",        name: "Metcon 9 Amp",            price: 22795, category: "Training",   image: "https://images.unsplash.com/photo-1549298916-b41d501d3772",        desc: "Built for every workout. Stable, durable, explosive.", stock: 20, status: "" },
  { id: 11, brand: "Off-White",   name: "Terra Forma",             price: 89995, category: "Training",   image: "https://images.unsplash.com/photo-1543508282-6319a3e46bc1",        desc: "Virgil Abloh's deconstructed masterpiece.", stock: 2, status: "High Art" },
];

const ProductDetails = ({ addToCart }) => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('sw_products');
    const list = stored ? JSON.parse(stored) : MOCK_PRODUCTS;
    const found = list.find((item) => String(item.id) === String(id));
    if (found && !found.desc) {
      const mock = MOCK_PRODUCTS.find(m => String(m.id) === String(id));
      setProduct({ ...found, desc: mock ? mock.desc : 'Premium quality shoe.' });
    } else {
      setProduct(found || MOCK_PRODUCTS.find(m => String(m.id) === String(id)));
    }
  }, [id]);

  if (!product) {
    return (
      <div className="h-screen flex flex-col items-center justify-center" style={{ background: '#0a0a0a' }}>
        <p className="text-xl font-bold" style={{ color: '#6b7280' }}>Loading...</p>
        <Link to="/products" className="mt-4 font-bold underline" style={{ color: '#EA580C' }}>Back to Products</Link>
      </div>
    );
  }

  const whatsappMessage = `Assalam o Alaikum! 🛒\nI want to order:\n\n👟 ${product.brand} - ${product.name}\n💰 Price: Rs. ${product.price.toLocaleString()}\n📦 Category: ${product.category}\n\nPlease confirm availability.`;
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(whatsappMessage)}`;

  const handleAddToCart = () => {
    if (product.stock === 0) return;
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="min-h-screen pt-28 pb-20 px-6 md:px-20" style={{ background: '#0a0a0a' }}>
      <Link to="/products"
        className="inline-flex items-center gap-2 text-sm font-black uppercase tracking-widest hover:opacity-80 transition-opacity mb-10"
        style={{ color: '#EA580C' }}>
        <ArrowLeft size={16} /> Back to Products
      </Link>

      <div className="grid md:grid-cols-2 gap-12 mt-4">
        {/* IMAGE */}
        <div className="rounded-3xl p-10 flex items-center justify-center"
          style={{ background: '#111111', border: '1px solid #1f1f1f', minHeight: '400px' }}>
          <img src={product.image} alt={product.name}
            className="w-full max-w-md object-contain mix-blend-luminosity" />
        </div>

        {/* DETAILS */}
        <div className="space-y-6">
          {product.status && (
            <span className="inline-block text-[9px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full text-white"
              style={{ background: product.status === 'Sold Out' ? '#374151' : '#EA580C' }}>
              {product.status}
            </span>
          )}

          <div>
            <h2 className="text-5xl font-black uppercase italic tracking-tighter" style={{ color: '#ffffff' }}>{product.brand}</h2>
            <h1 className="text-2xl font-bold mt-1" style={{ color: '#9ca3af' }}>{product.name}</h1>
          </div>

          <p className="text-4xl font-black italic" style={{ color: '#EA580C' }}>Rs. {product.price.toLocaleString()}</p>

          <p className="leading-relaxed text-sm font-medium" style={{ color: '#9ca3af' }}>{product.desc}</p>

          <div className="flex items-center gap-3">
            <span className="text-xs font-black uppercase tracking-widest px-4 py-2 rounded-xl"
              style={{ background: '#1a1a1a', color: product.stock > 0 ? '#6b7280' : '#ef4444', border: '1px solid #2f2f2f' }}>
              {product.stock > 0 ? `Stock: ${product.stock} left` : 'Out of Stock'}
            </span>
          </div>

          {/* BUTTONS */}
          <div className="space-y-3 pt-2">
            {product.stock > 0 ? (
              <>
                <button onClick={handleAddToCart}
                  className="w-full py-5 rounded-2xl font-black uppercase italic tracking-widest flex items-center justify-center gap-3 text-white transition-all hover:opacity-90"
                  style={{ background: added ? '#16a34a' : '#EA580C' }}>
                  <ShoppingBag size={20} />
                  {added ? '✓ Added to Cart!' : 'Add to Cart'}
                </button>
                <a href={whatsappUrl} target="_blank" rel="noopener noreferrer"
                  className="w-full py-5 rounded-2xl font-black uppercase italic tracking-widest flex items-center justify-center gap-3 text-white transition-all hover:opacity-90"
                  style={{ background: '#25D366', display: 'flex' }}>
                  📱 Order on WhatsApp
                </a>
              </>
            ) : (
              <p className="text-lg font-black uppercase italic" style={{ color: '#ef4444' }}>Out of Stock</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
