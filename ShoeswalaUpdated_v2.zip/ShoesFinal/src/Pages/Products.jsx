import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SlidersHorizontal, Search, Zap, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const DEFAULT_PRODUCTS = [
  { id: 1,  brand: "Nike",        name: "Air Max Pulse",          price: 34995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=800&auto=format&fit=crop", status: "New Drop",         colors: ["#000", "#EA580C"], stock: 12 },
  { id: 2,  brand: "Yeezy",       name: "Boost 350 V2 'Onyx'",    price: 52495, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1582588564157-60370c2170fe?q=80&w=800&auto=format&fit=crop", status: "Limited Release",  colors: ["#1A1A1A"],         stock: 6  },
  { id: 3,  brand: "New Balance", name: "9060 'Sea Salt'",         price: 31995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1639144345371-9df608402534?q=80&w=800&auto=format&fit=crop", status: "Trending",         colors: ["#F5F5DC"],         stock: 15 },
  { id: 4,  brand: "Nike",        name: "Dunk Low 'Panda'",        price: 24995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?q=80&w=800&auto=format&fit=crop", status: "Restocked",        colors: ["#FFF", "#000"],    stock: 25 },
  { id: 5,  brand: "Nike",        name: "Zoom Freak 5",            price: 28895, category: "Basketball", image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?q=80&w=800&auto=format&fit=crop", status: "Performance Elite",colors: ["#3B82F6", "#000"],  stock: 5  },
  { id: 6,  brand: "Jordan",      name: "AJ4 'Thunder'",           price: 68995, category: "Basketball", image: "https://images.unsplash.com/photo-1612817159949-195b6eb9e31a?q=80&w=800&auto=format&fit=crop", status: "Grail",             colors: ["#000", "#FFD700"], stock: 3  },
  { id: 7,  brand: "Jordan",      name: "Air Jordan 1 High",       price: 46995, category: "Basketball", image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=800&auto=format&fit=crop", status: "Sold Out",         colors: ["#FF0000","#FFF","#000"], stock: 0 },
  { id: 8,  brand: "Adidas",      name: "Ultraboost Light",        price: 38999, category: "Running",    image: "https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?q=80&w=800&auto=format&fit=crop", status: "Best Seller",      colors: ["#FFF", "#000"],    stock: 9  },
  { id: 9,  brand: "Hoka",        name: "Bondi 8 Black",           price: 27495, category: "Running",    image: "https://images.unsplash.com/photo-1620138546344-7b2c38516dee?q=80&w=800&auto=format&fit=crop", status: "Comfort King",     colors: ["#1A1A1A"],         stock: 14 },
  { id: 10, brand: "Nike",        name: "Metcon 9 Amp",            price: 22795, category: "Training",   image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=800&auto=format&fit=crop", status: "",                 colors: ["#71717A"],         stock: 20 },
  { id: 11, brand: "Off-White",   name: "Terra Forma",             price: 89995, category: "Training",   image: "https://images.unsplash.com/photo-1543508282-6319a3e46bc1?q=80&w=800&auto=format&fit=crop", status: "High Art",         colors: ["#000", "#32CD32"], stock: 2  },
];

const Products = ({ searchQuery: globalQuery }) => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [localSearch, setLocalSearch] = useState('');
  const [allProducts, setAllProducts] = useState([]);

  useEffect(() => {
    const loadProducts = () => {
      try {
        const stored = localStorage.getItem('sw_products');
        setAllProducts(stored ? JSON.parse(stored) : DEFAULT_PRODUCTS);
      } catch {
        setAllProducts(DEFAULT_PRODUCTS);
      }
    };
    loadProducts();
    window.addEventListener('focus', loadProducts);
    return () => window.removeEventListener('focus', loadProducts);
  }, []);

  const categories = ['All', 'Lifestyle', 'Running', 'Basketball', 'Training'];
  const query = globalQuery || localSearch;

  const filteredProducts = allProducts.filter(p =>
    (selectedCategory === 'All' || p.category === selectedCategory) &&
    (p.name.toLowerCase().includes(query.toLowerCase()) || p.brand.toLowerCase().includes(query.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-white pt-20 pb-20 selection:bg-orange-600 selection:text-white">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12">

        {/* HEADER */}
        <header className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-10 mb-16">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            <div className="inline-flex items-center gap-2 bg-orange-600 text-white px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-[0.2em]">
              <Zap size={12} className="fill-white" /> Authorized Retailer
            </div>
            <h1 className="text-7xl md:text-9xl font-[1000] italic uppercase tracking-tighter leading-[0.8] text-zinc-950">
              The <span className="text-orange-600">Vault</span>
            </h1>
            <p className="text-zinc-400 font-bold uppercase text-[10px] tracking-[0.3em] max-w-sm pt-2 flex items-center gap-2">
              <span className="w-8 h-px bg-zinc-200"></span> Verified Products Only
            </p>
          </motion.div>

          <div className="relative w-full lg:w-[450px] group">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-orange-600 transition-colors" size={20} />
            <input type="text" placeholder="SEARCH PRODUCTS..."
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              className="w-full bg-zinc-50 border-2 border-zinc-100 rounded-[1.5rem] py-6 pl-16 pr-8 focus:border-zinc-900 transition-all outline-none text-[11px] font-black uppercase tracking-widest shadow-sm" />
          </div>
        </header>

        {/* FILTER NAV */}
        <nav className="flex flex-col md:flex-row items-center justify-between gap-8 border-y-2 border-zinc-50 py-10 mb-16">
          <div className="flex items-center gap-4 overflow-x-auto no-scrollbar w-full md:w-auto">
            {categories.map((cat) => (
              <button key={cat} onClick={() => setSelectedCategory(cat)}
                className={`px-10 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  selectedCategory === cat
                    ? 'bg-zinc-950 text-white scale-105'
                    : 'bg-white text-zinc-400 hover:text-zinc-950 border border-zinc-100'
                }`}>
                {cat}
              </button>
            ))}
          </div>
          <button className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest bg-zinc-50 text-zinc-900 px-10 py-4 rounded-xl">
            <SlidersHorizontal size={16} /> Filter & Sort
          </button>
        </nav>

        {/* PRODUCT GRID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-10 gap-y-20">
          <AnimatePresence mode="popLayout">
            {filteredProducts.map((shoe) => (
              <motion.div key={shoe.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="group cursor-default">
                <Link to={`/product/${shoe.id}`}>
                  <div className="relative aspect-square bg-[#f7f7f7] rounded-[3rem] overflow-hidden p-12 transition-all duration-700 group-hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)]">
                    {shoe.status && (
                      <div className="absolute top-10 left-10 z-10">
                        <span className={`px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest border ${
                          shoe.status === 'Sold Out' ? 'bg-zinc-200 text-zinc-500' : 'bg-white text-orange-600'
                        }`}>
                          {shoe.status}
                        </span>
                      </div>
                    )}
                    <motion.img whileHover={{ scale: 1.1, rotate: -5 }}
                      src={shoe.image} alt={shoe.name}
                      className={`w-full h-full object-contain mix-blend-multiply drop-shadow-xl transition-all duration-700 ${shoe.stock === 0 ? 'grayscale opacity-50' : ''}`} />
                    <div className="absolute bottom-10 right-10 opacity-0 group-hover:opacity-100 transition-all">
                      <div className="bg-zinc-950 text-white p-4 rounded-2xl"><ArrowUpRight size={18} /></div>
                    </div>
                  </div>
                </Link>

                <div className="mt-8 px-2 space-y-2">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <p className="text-[9px] font-black text-zinc-400 uppercase tracking-widest">{shoe.brand}</p>
                      <h3 className="text-xl font-[1000] uppercase italic tracking-tighter text-zinc-950">{shoe.name}</h3>
                    </div>
                    <p className="text-lg font-black tracking-tighter italic text-zinc-950">Rs. {Number(shoe.price).toLocaleString()}</p>
                  </div>
                  <div className="flex gap-1.5 pt-2">
                    {(shoe.colors || []).map((c, i) => (
                      <div key={i} className="w-2.5 h-2.5 rounded-full border border-zinc-200" style={{ backgroundColor: c }}></div>
                    ))}
                  </div>
                  {shoe.stock === 0 && <p className="text-[9px] font-black uppercase tracking-widest text-red-400">Out of Stock</p>}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-32">
            <p className="text-zinc-300 text-6xl font-[1000] italic uppercase tracking-tighter">Koi product nahi</p>
          </div>
        )}
      </div>
      <style>{`.no-scrollbar::-webkit-scrollbar { display: none; }`}</style>
    </div>
  );
};

export default Products;
