import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Lock, LogOut, Plus, Trash2, Edit3, Save, X,
  Package, Eye, EyeOff, ShieldCheck, Image, Tag,
  ToggleLeft, ToggleRight, AlertTriangle
} from 'lucide-react';

const DEFAULT_PRODUCTS = [
  { id: 1,  brand: "Nike",        name: "Air Max Pulse",          price: 34995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=800&auto=format&fit=crop", status: "New Drop",         colors: ["#000", "#EA580C"], stock: 12 },
  { id: 2,  brand: "Yeezy",       name: "Boost 350 V2 'Onyx'",    price: 52495, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1582588564157-60370c2170fe?q=80&w=800&auto=format&fit=crop", status: "Limited Release",  colors: ["#1A1A1A"],         stock: 6  },
  { id: 3,  brand: "New Balance", name: "9060 'Sea Salt'",         price: 31995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1639144345371-9df608402534?q=80&w=800&auto=format&fit=crop", status: "Trending",         colors: ["#F5F5DC"],         stock: 15 },
  { id: 4,  brand: "Nike",        name: "Dunk Low 'Panda'",        price: 24995, category: "Lifestyle",  image: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?q=80&w=800&auto=format&fit=crop", status: "Restocked",        colors: ["#FFF", "#000"],    stock: 25 },
  { id: 5,  brand: "Nike",        name: "Zoom Freak 5",            price: 28895, category: "Basketball", image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?q=80&w=800&auto=format&fit=crop", status: "Performance Elite",colors: ["#3B82F6", "#000"],  stock: 5  },
  { id: 6,  brand: "Jordan",      name: "AJ4 'Thunder'",           price: 68995, category: "Basketball", image: "https://images.unsplash.com/photo-1612817159949-195b6eb9e31a?q=80&w=800&auto=format&fit=crop", status: "Grail",             colors: ["#000", "#FFD700"], stock: 3  },
  { id: 7,  brand: "Jordan",      name: "Air Jordan 1 High",       price: 46995, category: "Basketball", image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=800&auto=format&fit=crop", status: "Sold Out",         colors: ["#FF0000","#FFF","#000"], stock: 0 },
  { id: 8,  brand: "Adidas",      name: "Ultraboost Light",        price: 38999, category: "Running",    image: "https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?q=80&w=800&auto=format&fit=crop", status: "Best Seller",      colors: ["#FFF", "#000"],    stock: 9  },
  { id: 9,  brand: "Hoka",        name: "Bondi 8 Black",           price: 27495, category: "Running",    image: "https://images.unsplash.com/photo-1620138546344-7b2c38516dee?q=80&w=800&auto=format&fit=crop", status: "Comfort King",     colors: ["#1A1A1A"],         stock: 14 },
  { id: 10, brand: "Nike",        name: "Metcon 9 Amp",            price: 22795, category: "Training",   image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=800&auto=format&fit=crop", status: "",                 colors: ["#71717A"],         stock: 20 },
  { id: 11, brand: "Off-White",   name: "Terra Forma",             price: 89995, category: "Training",   image: "https://images.unsplash.com/photo-1543508282-6319a3e46bc1?q=80&w=800&auto=format&fit=crop", status: "High Art",         colors: ["#000", "#32CD32"], stock: 2  },
];

const ADMIN_USER = 'admin';
const ADMIN_PASS = 'shoeswala2026';
const CATEGORIES = ['Lifestyle', 'Running', 'Basketball', 'Training'];
const STATUS_OPTIONS = ['', 'New Drop', 'Limited Release', 'Trending', 'Restocked', 'Best Seller', 'Sold Out', 'Grail', 'High Art', 'Performance Elite', 'Comfort King'];

const getProducts = () => {
  try {
    const stored = localStorage.getItem('sw_products');
    return stored ? JSON.parse(stored) : DEFAULT_PRODUCTS;
  } catch { return DEFAULT_PRODUCTS; }
};
const saveProducts = (products) => localStorage.setItem('sw_products', JSON.stringify(products));
const emptyForm = () => ({ id: Date.now(), brand: '', name: '', price: '', category: 'Lifestyle', image: '', status: '', colors: ['#000000'], stock: '' });

const AdminPanel = () => {
  const [loggedIn, setLoggedIn] = useState(() => sessionStorage.getItem('sw_admin') === 'true');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [products, setProducts] = useState(getProducts);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm());
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => { if (loggedIn) saveProducts(products); }, [products, loggedIn]);

  const handleLogin = (e) => {
    e.preventDefault();
    if (username === ADMIN_USER && password === ADMIN_PASS) {
      sessionStorage.setItem('sw_admin', 'true');
      setLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Galat username ya password!');
    }
  };

  const handleLogout = () => { sessionStorage.removeItem('sw_admin'); setLoggedIn(false); };
  const startEdit = (product) => { setForm({ ...product, colors: [...product.colors] }); setEditing(product.id); };
  const startNew = () => { setForm(emptyForm()); setEditing('new'); };
  const cancelEdit = () => setEditing(null);
  const handleFormChange = (key, value) => setForm(f => ({ ...f, [key]: value }));
  const handleColorChange = (idx, val) => { const c = [...form.colors]; c[idx] = val; setForm(f => ({ ...f, colors: c })); };
  const addColor = () => setForm(f => ({ ...f, colors: [...f.colors, '#ffffff'] }));
  const removeColor = (idx) => setForm(f => ({ ...f, colors: f.colors.filter((_, i) => i !== idx) }));

  const handleSave = () => {
    if (!form.name || !form.brand || !form.price || !form.image) { alert('Name, Brand, Price aur Image URL zaroori hai!'); return; }
    const product = { ...form, price: Number(form.price), stock: Number(form.stock) || 0 };
    if (editing === 'new') { setProducts(prev => [product, ...prev]); }
    else { setProducts(prev => prev.map(p => p.id === editing ? product : p)); }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    setEditing(null);
  };

  const handleDelete = (id) => { setProducts(prev => prev.filter(p => p.id !== id)); setDeleteConfirm(null); };
  const toggleStock = (id) => {
    setProducts(prev => prev.map(p => p.id === id
      ? { ...p, stock: p.stock > 0 ? 0 : 10, status: p.stock > 0 ? 'Sold Out' : p.status === 'Sold Out' ? '' : p.status }
      : p));
  };

  if (!loggedIn) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center px-4">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-600 rounded-3xl mb-6"><Lock size={28} className="text-white" /></div>
            <h1 className="text-4xl font-[1000] italic uppercase tracking-tighter text-white">Admin<br /><span className="text-orange-600">Panel</span></h1>
            <p className="text-zinc-500 text-[10px] uppercase tracking-widest font-bold mt-2">Shoeswala Management</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-2">Username</label>
              <input type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder="admin"
                className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl px-6 py-4 text-white text-sm font-bold outline-none focus:border-orange-600 transition-colors" />
            </div>
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-2">Password</label>
              <div className="relative">
                <input type={showPass ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••"
                  className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl px-6 py-4 text-white text-sm font-bold outline-none focus:border-orange-600 transition-colors pr-14" />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-5 top-1/2 -translate-y-1/2 text-zinc-500">
                  {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>
            {loginError && (
              <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3">
                <AlertTriangle size={14} className="text-red-500" />
                <p className="text-red-400 text-xs font-bold">{loginError}</p>
              </div>
            )}
            <motion.button whileTap={{ scale: 0.97 }} type="submit"
              className="w-full bg-orange-600 text-white h-14 rounded-2xl font-black uppercase italic tracking-widest text-sm hover:bg-orange-700 transition-colors flex items-center justify-center gap-3 mt-2">
              <ShieldCheck size={18} /> Login Karo
            </motion.button>
          </form>
        </motion.div>
      </div>
    );
  }

  if (editing !== null) {
    return (
      <div className="min-h-screen bg-zinc-950 pt-24 pb-20 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-4xl font-[1000] italic uppercase tracking-tighter text-white">
              {editing === 'new' ? <><span className="text-orange-600">Naya</span> Product</> : <>Product <span className="text-orange-600">Edit</span></>}
            </h2>
            <button onClick={cancelEdit} className="text-zinc-400 hover:text-white transition-colors"><X size={24} /></button>
          </div>
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              {[['brand','Brand *','Nike, Adidas...'],['name','Product Name *','Air Max Pulse...']].map(([key,label,ph]) => (
                <div key={key}>
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-2">{label}</label>
                  <input value={form[key]} onChange={e => handleFormChange(key, e.target.value)} placeholder={ph}
                    className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl px-5 py-4 text-white text-sm font-bold outline-none focus:border-orange-600 transition-colors" />
                </div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[['price','Price (Rs.) *','34995','number'],['stock','Stock','10','number']].map(([key,label,ph,type]) => (
                <div key={key}>
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-2">{label}</label>
                  <input type={type} value={form[key]} onChange={e => handleFormChange(key, e.target.value)} placeholder={ph}
                    className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl px-5 py-4 text-white text-sm font-bold outline-none focus:border-orange-600 transition-colors" />
                </div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-2">Category</label>
                <select value={form.category} onChange={e => handleFormChange('category', e.target.value)}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl px-5 py-4 text-white text-sm font-bold outline-none focus:border-orange-600 transition-colors">
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-2">Status Badge</label>
                <select value={form.status} onChange={e => handleFormChange('status', e.target.value)}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl px-5 py-4 text-white text-sm font-bold outline-none focus:border-orange-600 transition-colors">
                  {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s || '(Koi nahi)'}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-2 flex items-center gap-2"><Image size={12} /> Image URL *</label>
              <input value={form.image} onChange={e => handleFormChange('image', e.target.value)} placeholder="https://images.unsplash.com/..."
                className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl px-5 py-4 text-white text-sm font-bold outline-none focus:border-orange-600 transition-colors" />
              {form.image && (
                <div className="mt-3 w-24 h-24 bg-zinc-800 rounded-2xl p-2 overflow-hidden">
                  <img src={form.image} alt="preview" className="w-full h-full object-contain mix-blend-multiply" onError={e => e.target.style.display='none'} />
                </div>
              )}
            </div>
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-3">Colors</label>
              <div className="flex gap-3 flex-wrap">
                {form.colors.map((c, idx) => (
                  <div key={idx} className="flex items-center gap-2 bg-zinc-900 rounded-2xl px-3 py-2 border-2 border-zinc-800">
                    <input type="color" value={c} onChange={e => handleColorChange(idx, e.target.value)} className="w-8 h-8 rounded-xl border-0 cursor-pointer bg-transparent" />
                    <span className="text-zinc-400 text-xs font-mono">{c}</span>
                    {form.colors.length > 1 && (
                      <button onClick={() => removeColor(idx)} className="text-zinc-600 hover:text-red-500 transition-colors"><X size={14} /></button>
                    )}
                  </div>
                ))}
                <button onClick={addColor} className="flex items-center gap-2 bg-zinc-900 border-2 border-dashed border-zinc-700 rounded-2xl px-4 py-2 text-zinc-500 hover:border-orange-600 hover:text-orange-600 transition-colors text-xs font-bold">
                  <Plus size={14} /> Add
                </button>
              </div>
            </div>
            <motion.button whileTap={{ scale: 0.97 }} onClick={handleSave}
              className="w-full bg-orange-600 text-white h-14 rounded-2xl font-black uppercase italic tracking-widest text-sm hover:bg-orange-700 transition-colors flex items-center justify-center gap-3 mt-4">
              <Save size={18} /> {editing === 'new' ? 'Product Add Karo' : 'Changes Save Karo'}
            </motion.button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 pt-24 pb-20 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-10">
          <div>
            <h1 className="text-5xl font-[1000] italic uppercase tracking-tighter text-white">Admin <span className="text-orange-600">Panel</span></h1>
            <p className="text-zinc-500 text-[10px] uppercase tracking-widest font-bold mt-1">{products.length} Products • Shoeswala</p>
          </div>
          <div className="flex gap-3">
            <AnimatePresence>
              {saved && (
                <motion.div initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}
                  className="flex items-center gap-2 bg-green-500/20 border border-green-500/30 text-green-400 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest">
                  <Save size={12} /> Saved!
                </motion.div>
              )}
            </AnimatePresence>
            <motion.button whileTap={{ scale: 0.95 }} onClick={startNew}
              className="flex items-center gap-2 bg-orange-600 text-white px-6 py-3 rounded-2xl font-black uppercase italic tracking-widest text-xs hover:bg-orange-700 transition-colors">
              <Plus size={16} /> Naya Product
            </motion.button>
            <button onClick={handleLogout} className="flex items-center gap-2 bg-zinc-900 text-zinc-400 px-5 py-3 rounded-2xl font-black uppercase text-xs tracking-widest hover:text-red-400 transition-colors border border-zinc-800">
              <LogOut size={14} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-10">
          {[
            { label: 'Total Products', val: products.length, icon: Package },
            { label: 'In Stock', val: products.filter(p => p.stock > 0).length, icon: Tag },
            { label: 'Sold Out', val: products.filter(p => p.stock === 0).length, icon: AlertTriangle },
          ].map(({ label, val, icon: Icon }) => (
            <div key={label} className="bg-zinc-900 rounded-3xl p-6 border border-zinc-800">
              <Icon size={20} className="text-orange-600 mb-3" />
              <p className="text-3xl font-[1000] italic text-white">{val}</p>
              <p className="text-[9px] font-black uppercase tracking-widest text-zinc-500 mt-1">{label}</p>
            </div>
          ))}
        </div>

        <div className="space-y-3">
          {products.map((p) => (
            <motion.div key={p.id} layout className="bg-zinc-900 rounded-3xl border border-zinc-800 p-4 flex items-center gap-4 hover:border-zinc-700 transition-colors">
              <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex-shrink-0 overflow-hidden p-2">
                <img src={p.image} alt={p.name} className="w-full h-full object-contain mix-blend-multiply" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-[9px] font-black uppercase tracking-widest text-zinc-500">{p.brand}</p>
                  {p.status && <span className="text-[8px] font-black uppercase tracking-widest bg-orange-600/10 text-orange-500 px-2 py-0.5 rounded-lg">{p.status}</span>}
                </div>
                <p className="text-white font-black italic uppercase tracking-tighter truncate">{p.name}</p>
                <p className="text-zinc-400 text-xs font-bold mt-0.5">Rs. {Number(p.price).toLocaleString()}</p>
              </div>
              <div className="flex flex-col items-center gap-1 flex-shrink-0">
                <button onClick={() => toggleStock(p.id)} className="transition-colors">
                  {p.stock > 0 ? <ToggleRight size={28} className="text-green-500" /> : <ToggleLeft size={28} className="text-zinc-600" />}
                </button>
                <span className={`text-[8px] font-black uppercase tracking-widest ${p.stock > 0 ? 'text-green-500' : 'text-zinc-600'}`}>
                  {p.stock > 0 ? `${p.stock} left` : 'Out'}
                </span>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => startEdit(p)} className="w-10 h-10 bg-zinc-800 hover:bg-zinc-700 rounded-xl flex items-center justify-center text-zinc-400 hover:text-white transition-colors">
                  <Edit3 size={16} />
                </button>
                <button onClick={() => setDeleteConfirm(p.id)} className="w-10 h-10 bg-zinc-800 hover:bg-red-500/20 rounded-xl flex items-center justify-center text-zinc-400 hover:text-red-500 transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {deleteConfirm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 px-4">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }}
              className="bg-zinc-900 border border-zinc-700 rounded-3xl p-8 max-w-sm w-full text-center">
              <AlertTriangle size={40} className="text-red-500 mx-auto mb-4" />
              <h3 className="text-2xl font-[1000] italic uppercase tracking-tighter text-white mb-2">Delete?</h3>
              <p className="text-zinc-400 text-sm mb-6">Yeh product hamesha k lye delete ho jayega.</p>
              <div className="flex gap-3">
                <button onClick={() => setDeleteConfirm(null)} className="flex-1 h-12 rounded-2xl bg-zinc-800 text-zinc-300 font-black uppercase text-xs tracking-widest hover:bg-zinc-700 transition-colors">Cancel</button>
                <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 h-12 rounded-2xl bg-red-600 text-white font-black uppercase italic text-xs tracking-widest hover:bg-red-700 transition-colors">Haan, Delete</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AdminPanel;
