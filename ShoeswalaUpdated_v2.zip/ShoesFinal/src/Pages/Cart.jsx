import React, { useState } from 'react';
import { Trash2, ShoppingBag, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Cart = ({ cartItems = [], removeFromCart, clearCart }) => {
  const [success, setSuccess] = useState(false);
  const [info, setInfo] = useState({ name: '', phone: '', address: '', city: '', option: 'Website Order' });
  const navigate = useNavigate();

  const baseAmount = cartItems.reduce((acc, curr) => acc + curr.price, 0);
  const shippingFee = cartItems.length > 0 ? 250 : 0;
  const totalAmount = baseAmount + shippingFee;

  const handleProcessCheckout = () => {
    const breakdown = cartItems.map((item, i) => `${i + 1}. ⭐ *${item.brand} - ${item.name}* (Rs. ${item.price.toLocaleString()})`).join('\n');
    const orderMethod = info.option === 'WhatsApp Stream' ? 'WHATSAPP STREAM DROPS' : 'DIRECT WEBSITE CHECKOUT';
    const text = `🛒 *NEW ORDER - SHOESWALA*\n⚡ *Method:* ${orderMethod}\n\n📋 *Customer:* ${info.name}\n📞 *Phone:* ${info.phone}\n📍 *Address:* ${info.address}, ${info.city}\n\n👟 *Selected Items:*\n${breakdown}\n\n📦 *Shipping:* Rs. ${shippingFee}\n🔥 *Total Payable Amount:* Rs. ${totalAmount.toLocaleString()}`;
    window.open(`https://wa.me/923122347756?text=${encodeURIComponent(text)}`, '_blank');
    setSuccess(true);
    clearCart();
  };

  if (success) {
    return (
      <div className="h-[75vh] flex flex-col items-center justify-center text-center px-6 bg-zinc-950">
        <CheckCircle size={64} className="text-orange-500 mb-4 animate-pulse" />
        <h2 className="text-4xl font-[1000] italic uppercase tracking-tighter mb-2 text-white">
          Order <span className="text-orange-500">Logged!</span>
        </h2>
        <p className="text-zinc-300 text-xs font-bold uppercase tracking-wider max-w-sm leading-relaxed">
          Shoeswala team aap se jald raabta karegi! Order details aapke WhatsApp par generate ho chuki hain.
        </p>
        <button onClick={() => navigate('/')}
          className="mt-8 px-8 py-4 bg-zinc-900 border border-zinc-800 rounded-xl font-black text-[10px] uppercase tracking-widest text-orange-500 hover:text-white hover:border-orange-500 transition-all shadow-xl">
          Back To Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-12 py-10">
      <div className="border-b border-zinc-900 pb-6 mb-10 flex justify-between items-center">
        <h1 className="text-3xl md:text-4xl font-[1000] uppercase italic tracking-tighter flex items-center gap-3 text-white">
          Shopping <span className="text-orange-500">Basket</span> <ShoppingBag className="text-orange-500" />
        </h1>
        {cartItems.length > 0 && (
          <button onClick={clearCart} className="text-[10px] font-black uppercase tracking-widest text-zinc-500 hover:text-red-500 transition-colors">
            Clear All
          </button>
        )}
      </div>

      {cartItems.length === 0 ? (
        <div className="h-[40vh] flex flex-col items-center justify-center text-center">
          <p className="text-zinc-500 text-sm font-bold italic uppercase tracking-wider">Aapka basket khali hai.</p>
          <button onClick={() => navigate('/products')} className="mt-4 px-6 py-3 bg-zinc-900 border border-zinc-800 rounded-xl font-black text-[10px] uppercase tracking-widest text-white hover:border-orange-500 transition-all">
            Explore The Vault
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative">

          {/* LEFT: Items + Form */}
          <div className="lg:col-span-7 space-y-10 order-2 lg:order-1">
            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400">Selected Items ({cartItems.length})</h3>
              <div className="space-y-3">
                {cartItems.map((shoe, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-zinc-900/40 border border-zinc-900 p-4 rounded-2xl hover:border-zinc-800 transition-all">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-zinc-900 rounded-xl p-2 flex items-center justify-center overflow-hidden">
                        <img src={shoe.image} alt={shoe.name} className="w-full h-full object-contain mix-blend-screen" />
                      </div>
                      <div>
                        <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-wider">{shoe.brand}</span>
                        <h4 className="font-black text-sm uppercase tracking-tight text-white leading-tight">{shoe.name}</h4>
                        <p className="text-xs text-orange-500 font-extrabold mt-0.5">Rs. {shoe.price.toLocaleString()}</p>
                      </div>
                    </div>
                    <button onClick={() => removeFromCart(idx)} className="p-2 bg-zinc-950/50 border border-zinc-800 rounded-lg text-zinc-500 hover:text-red-500 hover:border-red-500/20 transition-all">
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* CUSTOMER FORM */}
            <div className="bg-zinc-900/20 border border-zinc-900/60 p-6 md:p-8 rounded-[2.5rem] space-y-6">
              <div>
                <h3 className="text-lg font-[1000] uppercase italic tracking-tighter text-white">Delivery Details 📦</h3>
                <p className="text-zinc-500 text-[11px] font-medium">Please provide accurate info for effortless package dispatch.</p>
              </div>
              <div className="space-y-4">
                {[
                  { label: 'Full Name', key: 'name', placeholder: 'e.g., Baber Umer', type: 'text' },
                  { label: 'Mobile Number', key: 'phone', placeholder: 'e.g., 03XXXXXXXXX', type: 'tel' },
                  { label: 'Ghar Ka Pata (Address)', key: 'address', placeholder: 'House/Apartment #, Street, Sector', type: 'text' },
                  { label: 'City', key: 'city', placeholder: 'Karachi, Lahore, Islamabad...', type: 'text' },
                ].map(({ label, key, placeholder, type }) => (
                  <div key={key}>
                    <label className="block text-[9px] font-black uppercase tracking-widest text-zinc-400 mb-1.5">{label}</label>
                    <input type={type} placeholder={placeholder} required value={info[key]}
                      onChange={e => setInfo({ ...info, [key]: e.target.value })}
                      className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-4 py-3.5 text-xs text-white focus:outline-none focus:border-orange-500 transition-colors" />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT: Summary */}
          <div className="lg:col-span-5 lg:sticky lg:top-28 order-1 lg:order-2">
            <div className="bg-zinc-950 border-2 border-orange-500/60 p-6 md:p-8 rounded-[2.5rem] shadow-2xl shadow-orange-500/5 space-y-6">
              <h2 className="text-2xl font-[1000] uppercase italic tracking-tighter border-b border-zinc-900 pb-3 text-white">SUMMARY</h2>

              <div className="space-y-3.5 text-xs">
                {cartItems.map((item, i) => (
                  <div key={i} className="flex justify-between items-center text-zinc-400 font-medium">
                    <span className="truncate max-w-[200px] uppercase text-[11px] font-bold">{item.name}</span>
                    <span className="font-black text-white">Rs. {item.price.toLocaleString()}</span>
                  </div>
                ))}
                <div className="flex justify-between items-center text-zinc-400 border-t border-zinc-900 pt-3">
                  <span className="uppercase text-[10px] font-bold tracking-wider">SHIPPING</span>
                  <span className="font-black text-white">Rs. {shippingFee}</span>
                </div>
                <div className="pt-4 border-t-2 border-dashed border-zinc-900 flex flex-col space-y-1">
                  <span className="text-[9px] font-black uppercase tracking-widest text-zinc-500">TOTAL PAYABLE</span>
                  <div className="text-3xl font-[1000] text-orange-500 italic tracking-tighter">Rs. {totalAmount.toLocaleString()}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button type="button" onClick={() => setInfo({ ...info, option: 'Website Order' })}
                  className={`py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${info.option === 'Website Order' ? 'bg-orange-500 border-orange-500 text-white shadow-lg shadow-orange-500/20' : 'bg-zinc-900/50 border-zinc-900 text-zinc-400 hover:text-white'}`}>
                  Direct Order
                </button>
                <button type="button" onClick={() => setInfo({ ...info, option: 'WhatsApp Stream' })}
                  className={`py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${info.option === 'WhatsApp Stream' ? 'bg-green-600 border-green-600 text-white shadow-lg shadow-green-600/20' : 'bg-zinc-900/50 border-zinc-900 text-zinc-400 hover:text-white'}`}>
                  WhatsApp Order
                </button>
              </div>

              <button onClick={handleProcessCheckout}
                disabled={!info.name || !info.phone || !info.address || !info.city}
                className="w-full bg-white text-zinc-950 disabled:bg-zinc-800 disabled:text-zinc-600 disabled:cursor-not-allowed font-black text-[11px] uppercase tracking-widest py-4 rounded-xl shadow-xl transition-all hover:bg-orange-500 hover:text-white">
                Place Final Order
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
